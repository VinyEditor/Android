package com.example.myapplication

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Toast
import androidx.activity.ComponentActivity
import com.example.myapplication.databinding.ActivityMainBinding


class MainActivity : ComponentActivity() {

    private lateinit var binding:  ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        binding.button.setOnClickListener {
            binding.textview.text = binding.edittext.text
        }

        binding.imageview.setOnClickListener{
            Toast.makeText(this, "Clicou na imagem", Toast.LENGTH_LONG).show()
        }
    }
}

